#include <cstdio>

void main()
{ 
    printf("Hola mundo");

}
